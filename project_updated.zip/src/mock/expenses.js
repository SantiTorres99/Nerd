export const initialExpenses = [
  {
    id: 1,
    description: "Televisor 4K",
    totalAmount: 1200,
    installments: 12,
    paidInstallments: 3,
    category: "Electrónica",
    date: "2023-04-15",
    isFixed: false
  },
  {
    id: 2,
    description: "Sofá cama",
    totalAmount: 800,
    installments: 6,
    paidInstallments: 2,
    category: "Hogar",
    date: "2023-05-10",
    isFixed: false
  }
];

export const initialFixedExpenses = [
  {
    id: 101,
    description: "Alquiler",
    amount: 500,
    category: "Vivienda",
    paymentDate: "05",
    isActive: true
  },
  {
    id: 102,
    description: "Internet",
    amount: 60,
    category: "Servicios",
    paymentDate: "10",
    isActive: true
  },
  {
    id: 103,
    description: "Gimnasio",
    amount: 30,
    category: "Salud",
    paymentDate: "01",
    isActive: true
  }
];

export const initialIncome = 3000;