import React, { useState } from 'react';
import { initialExpenses, initialFixedExpenses, initialIncome } from './mock/expenses';
import ExpenseForm from './components/ExpenseForm';
import IncomeTracker from './components/IncomeTracker';
import BalanceSummary from './components/BalanceSummary';
import FixedExpensesTable from './components/FixedExpensesTable';
import VariableExpensesTable from './components/VariableExpensesTable';

const App = () => {
  const [expenses, setExpenses] = useState(initialExpenses);
  const [fixedExpenses, setFixedExpenses] = useState(initialFixedExpenses);
  const [income, setIncome] = useState(initialIncome);
  const [activeTab, setActiveTab] = useState('gastos');

  const handleAddExpense = (newExpense) => {
    setExpenses([...expenses, newExpense]);
  };

  const handleUpdatePaidInstallments = (id, newPaidInstallments) => {
    setExpenses(expenses.map(expense => (
      expense.id === id ? { 
        ...expense, 
        paidInstallments: Math.max(1, Math.min(newPaidInstallments, expense.installments)) 
      } : expense
    )));
  };

  const handleDeleteVariableExpense = (id) => {
    setExpenses(expenses.filter(expense => expense.id !== id));
  };

  const totalFixedExpenses = fixedExpenses
    .filter(expense => expense.isActive)
    .reduce((sum, expense) => sum + expense.amount, 0);

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800">Gastos Al Instante</h1>
          <div className="text-sm text-gray-500">Desktop v1.0</div>
        </div>
        
        <IncomeTracker income={income} onIncomeChange={setIncome} />
        
        <BalanceSummary 
          income={income} 
          expenses={expenses} 
          fixedExpenses={totalFixedExpenses} 
        />
        
        <div className="flex border-b border-gray-200 mb-4">
          <button
            className={`py-2 px-4 font-medium ${activeTab === 'gastos' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500'}`}
            onClick={() => setActiveTab('gastos')}
          >
            Gastos Variables
          </button>
          <button
            className={`py-2 px-4 font-medium ${activeTab === 'fijos' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500'}`}
            onClick={() => setActiveTab('fijos')}
          >
            Gastos Fijos
          </button>
        </div>
        
        {activeTab === 'gastos' ? (
          <>
            <ExpenseForm onAddExpense={handleAddExpense} />
            
            <div className="mt-6">
              <VariableExpensesTable
                expenses={expenses}
                onUpdatePaidInstallments={handleUpdatePaidInstallments}
                onDeleteExpense={handleDeleteVariableExpense}
              />
            </div>
          </>
        ) : (
          <FixedExpensesTable 
            fixedExpenses={fixedExpenses} 
            setFixedExpenses={setFixedExpenses} 
          />
        )}
      </div>
    </div>
  );
};

export default App;

// DONE

INSTRUCCIONES ADICIONALES PARA EL USUARIO:

1. Necesitarás instalar Electron globalmente si no lo tienes:
npm install -g electron

2. Para instalar las dependencias:
npm install

3. Para construir la aplicación React:
npm run react-build

4. Para iniciar la aplicación de escritorio:
npm start

5. Para construir el ejecutable (requiere electron-builder):
npm run build

Nota: Necesitarás agregar un icono en /public/icon.png y /public/icon.ico para que la aplicación tenga iconos personalizados.