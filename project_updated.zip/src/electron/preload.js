window.electron = {
  require: require,
  process: process
};