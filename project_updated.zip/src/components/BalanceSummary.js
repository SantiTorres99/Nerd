import React from 'react';
import { formatCurrency } from '../utils/format';

const BalanceSummary = ({ income, expenses, fixedExpenses = 0 }) => {
  const totalVariableExpenses = expenses.reduce((sum, expense) => {
    const installmentAmount = expense.totalAmount / expense.installments;
    return sum + (installmentAmount * expense.paidInstallments);
  }, 0);

  const totalExpenses = totalVariableExpenses + fixedExpenses;
  const remainingBalance = income - totalExpenses;

  return (
    <div className="p-4 mb-6 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl text-white">
      <h2 className="text-xl font-semibold mb-2">Resumen Financiero</h2>
      <div className="grid grid-cols-3 gap-4">
        <div>
          <p className="text-sm opacity-80">Ingresos</p>
          <p className="text-2xl font-bold">{formatCurrency(income)}</p>
        </div>
        <div>
          <p className="text-sm opacity-80">Gastos Variables</p>
          <p className="text-2xl font-bold">{formatCurrency(totalVariableExpenses)}</p>
        </div>
        <div>
          <p className="text-sm opacity-80">Gastos Fijos</p>
          <p className="text-2xl font-bold">{formatCurrency(fixedExpenses)}</p>
        </div>
      </div>
      <div className="mt-4 pt-4 border-t border-white border-opacity-20">
        <p className="text-sm opacity-80">Saldo disponible</p>
        <p className={`text-3xl font-bold ${remainingBalance >= 0 ? 'text-green-300' : 'text-red-300'}`}>
          {formatCurrency(remainingBalance)}
        </p>
      </div>
    </div>
  );
};

export default BalanceSummary;

// DONE