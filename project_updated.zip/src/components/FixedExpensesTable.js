import React, { useState } from 'react';
import { formatCurrency } from '../utils/format';

const FixedExpensesTable = ({ fixedExpenses, setFixedExpenses }) => {
  const [newExpense, setNewExpense] = useState({
    description: '',
    amount: '',
    category: 'Vivienda',
    paymentDate: '01',
    isActive: true
  });

  const sortedExpenses = [...fixedExpenses].sort((a, b) => 
    parseInt(a.paymentDate) - parseInt(b.paymentDate)
  );

  const handleDeleteClick = (id, description) => {
    if (window.confirm(`¿Estás seguro de que quieres eliminar el gasto fijo "${description}"?`)) {
      setFixedExpenses(fixedExpenses.filter(expense => expense.id !== id));
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setNewExpense({
      ...newExpense,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleAddFixedExpense = (e) => {
    e.preventDefault();
    if (!newExpense.description || !newExpense.amount) return;

    const expenseToAdd = {
      ...newExpense,
      id: Date.now(),
      amount: parseFloat(newExpense.amount.replace(',', '.'))
    };

    setFixedExpenses([...fixedExpenses, expenseToAdd]);
    setNewExpense({
      description: '',
      amount: '',
      category: 'Vivienda',
      paymentDate: '01',
      isActive: true
    });
  };

  const handleToggleActive = (id) => {
    setFixedExpenses(fixedExpenses.map(expense => 
      expense.id === id ? { ...expense, isActive: !expense.isActive } : expense
    ));
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-4 mb-6">
      <h2 className="text-xl font-semibold mb-4">Gastos Fijos</h2>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Descripción</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Monto</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Categoría</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Día de pago</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Activo</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {sortedExpenses.map((expense) => (
              <tr key={expense.id} className={!expense.isActive ? 'bg-gray-50' : ''}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {expense.description}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {formatCurrency(expense.amount)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {expense.category}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {expense.paymentDate}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <input
                    type="checkbox"
                    checked={expense.isActive}
                    onChange={() => handleToggleActive(expense.id)}
                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button
                    onClick={() => handleDeleteClick(expense.id, expense.description)}
                    className="text-red-600 hover:text-red-900"
                  >
                    Eliminar
                  </button>
                </td>
              </tr>
            ))}
            <tr className="bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <input
                  type="text"
                  name="description"
                  value={newExpense.description}
                  onChange={handleInputChange}
                  placeholder="Descripción"
                  className="p-1 border border-gray-300 rounded-md w-full"
                />
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <input
                  type="text"
                  name="amount"
                  value={newExpense.amount}
                  onChange={handleInputChange}
                  placeholder="Monto"
                  className="p-1 border border-gray-300 rounded-md w-full"
                />
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <select
                  name="category"
                  value={newExpense.category}
                  onChange={handleInputChange}
                  className="p-1 border border-gray-300 rounded-md w-full"
                >
                  <option value="Vivienda">Vivienda</option>
                  <option value="Servicios">Servicios</option>
                  <option value="Salud">Salud</option>
                  <option value="Transporte">Transporte</option>
                  <option value="Entretenimiento">Entretenimiento</option>
                </select>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <select
                  name="paymentDate"
                  value={newExpense.paymentDate}
                  onChange={handleInputChange}
                  className="p-1 border border-gray-300 rounded-md w-full"
                >
                  {Array.from({length: 31}, (_, i) => (
                    <option key={i+1} value={String(i+1).padStart(2, '0')}>
                      {String(i+1).padStart(2, '0')}
                    </option>
                  ))}
                </select>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <input
                  type="checkbox"
                  name="isActive"
                  checked={newExpense.isActive}
                  onChange={handleInputChange}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <button
                  onClick={handleAddFixedExpense}
                  className="px-3 py-1 bg-indigo-600 text-white rounded-md text-sm hover:bg-indigo-700"
                >
                  Agregar
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default FixedExpensesTable;

// DONE