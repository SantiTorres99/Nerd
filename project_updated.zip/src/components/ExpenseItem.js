import React from 'react';
import { formatCurrency } from '../utils/format';

const ExpenseItem = ({ expense, onUpdatePaidInstallments }) => {
  const installmentAmount = expense.totalAmount / expense.installments;
  const remainingAmount = expense.totalAmount - (installmentAmount * expense.paidInstallments);
  const remainingInstallments = expense.installments - expense.paidInstallments;
  
  const progressPercentage = (expense.paidInstallments / expense.installments) * 100;

  return (
    <div className="p-4 mb-4 bg-white rounded-xl shadow-md transition-all hover:shadow-lg">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-lg font-semibold">{expense.description}</h3>
        <span className="text-indigo-600 font-medium">{formatCurrency(expense.totalAmount)}</span>
      </div>
      
      <div className="flex justify-between text-sm text-gray-600 mb-3">
        <span>Categoría: {expense.category}</span>
        <span>Fecha: {expense.date}</span>
      </div>
      
      <div className="w-full bg-gray-200 rounded-full h-2.5 mb-3">
        <div 
          className="bg-indigo-600 h-2.5 rounded-full" 
          style={{ width: `${progressPercentage}%` }}
        ></div>
      </div>
      
      <div className="flex justify-between text-sm">
        <div>
          <span className="text-gray-500">Cuotas: </span>
          <span>{expense.paidInstallments} / {expense.installments}</span>
        </div>
        <div>
          <span className="text-gray-500">Falta pagar: </span>
          <span className="font-medium">{formatCurrency(remainingAmount)} ({remainingInstallments} cuotas)</span>
        </div>
      </div>
      
      <div className="flex mt-3">
        <button 
          onClick={() => onUpdatePaidInstallments(expense.id, expense.paidInstallments + 1)}
          disabled={expense.paidInstallments >= expense.installments}
          className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-md text-sm hover:bg-indigo-200 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Marcar cuota pagada
        </button>
      </div>
    </div>
  );
};

export default ExpenseItem;