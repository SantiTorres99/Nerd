import React, { useState } from 'react';
import { formatCurrency } from '../utils/format';

const ExpenseForm = ({ onAddExpense }) => {
  const [description, setDescription] = useState('');
  const [totalAmount, setTotalAmount] = useState('');
  const [displayAmount, setDisplayAmount] = useState('');
  const [installments, setInstallments] = useState('1');
  const [category, setCategory] = useState('Otros');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  const handleAmountChange = (e) => {
    const value = e.target.value
      .replace(/\./g, '')
      .replace(',', '.');
    
    setDisplayAmount(e.target.value);
    setTotalAmount(value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!description || !totalAmount) return;
    
    const newExpense = {
      id: Date.now(),
      description,
      totalAmount: parseFloat(totalAmount),
      installments: parseInt(installments),
      paidInstallments: 1,
      category,
      date
    };
    
    onAddExpense(newExpense);
    
    // Reset form
    setDescription('');
    setDisplayAmount('');
    setTotalAmount('');
    setInstallments('1');
    setCategory('Otros');
  };

  return (
    <div className="p-4 mb-6 bg-white rounded-xl shadow-md">
      <h2 className="text-xl font-semibold mb-4">Agregar Nuevo Gasto</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">Descripción</label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="¿En qué gastaste?"
            required
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Total</label>
            <div className="relative">
              <span className="absolute left-3 top-2 text-gray-400">$</span>
              <input
                type="text"
                value={displayAmount}
                onChange={handleAmountChange}
                className="w-full pl-8 p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="0,00"
                required
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Cuotas</label>
            <div className="relative">
              <select
                value={installments}
                onChange={(e) => setInstallments(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              >
                {[...Array(24)].map((_, i) => (
                  <option key={i+1} value={i+1}>{i+1} {i === 0 ? 'cuota' : 'cuotas'}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Categoría</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="Alimentación">Alimentación</option>
              <option value="Transporte">Transporte</option>
              <option value="Hogar">Hogar</option>
              <option value="Entretenimiento">Entretenimiento</option>
              <option value="Salud">Salud</option>
              <option value="Educación">Educación</option>
              <option value="Otros">Otros</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Fecha</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
        </div>
        
        <button
          type="submit"
          className="w-full py-2 px-4 bg-indigo-600 text-white font-medium rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-colors"
        >
          Agregar Gasto
        </button>
      </form>
    </div>
  );
};

export default ExpenseForm;

// DONE