import React, { useState } from 'react';
import { formatCurrency } from '../utils/format';

const IncomeTracker = ({ income, onIncomeChange }) => {
  const [inputValue, setInputValue] = useState(income.toString().replace('.', ','));

  const handleChange = (e) => {
    const value = e.target.value
      .replace(/\./g, '')
      .replace(',', '.');
    
    setInputValue(e.target.value);
    onIncomeChange(parseFloat(value) || 0);
  };

  return (
    <div className="p-4 mb-6 bg-white rounded-xl shadow-md">
      <h2 className="text-xl font-semibold mb-4">Tus Ingresos</h2>
      <div className="flex items-center">
        <span className="mr-2 text-gray-600">$</span>
        <input
          type="text"
          value={inputValue}
          onChange={handleChange}
          className="flex-1 p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          placeholder="Ingresa tus ingresos mensuales"
        />
      </div>
      <p className="text-sm text-gray-500 mt-1">
        Ingreso actual: {formatCurrency(income)}
      </p>
    </div>
  );
};

export default IncomeTracker;