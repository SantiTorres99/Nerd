import React from 'react';
import { formatCurrency } from '../utils/format';

const VariableExpensesTable = ({ expenses, onUpdatePaidInstallments, onDeleteExpense }) => {
  const handleDeleteClick = (id, description) => {
    if (window.confirm(`¿Estás seguro de que quieres eliminar el gasto "${description}"?`)) {
      onDeleteExpense(id);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-4 mb-6 overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Descripción</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cuotas</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pagadas</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Faltan</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {expenses.map((expense) => {
            const installmentAmount = expense.totalAmount / expense.installments;
            const remainingAmount = expense.totalAmount - (installmentAmount * expense.paidInstallments);
            const remainingInstallments = expense.installments - expense.paidInstallments;
            const progressPercentage = (expense.paidInstallments / expense.installments) * 100;

            return (
              <tr key={expense.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {expense.description}
                  <div className="text-xs text-gray-500">{expense.category} - {expense.date}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {formatCurrency(expense.totalAmount)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {expense.installments}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {expense.paidInstallments} ({formatCurrency(installmentAmount * expense.paidInstallments)})
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {remainingInstallments} ({formatCurrency(remainingAmount)})
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium flex items-center space-x-2">
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => onUpdatePaidInstallments(expense.id, expense.paidInstallments - 1)}
                      disabled={expense.paidInstallments <= 1}
                      className="px-2 py-1 bg-red-100 text-red-700 rounded-md text-xs hover:bg-red-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      -
                    </button>
                    <span className="w-6 text-center">{expense.paidInstallments}</span>
                    <button
                      onClick={() => onUpdatePaidInstallments(expense.id, expense.paidInstallments + 1)}
                      disabled={expense.paidInstallments >= expense.installments}
                      className="px-2 py-1 bg-green-100 text-green-700 rounded-md text-xs hover:bg-green-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      +
                    </button>
                  </div>
                  <div className="w-16 ml-2 bg-gray-200 rounded-full h-1.5">
                    <div 
                      className="bg-indigo-600 h-1.5 rounded-full" 
                      style={{ width: `${progressPercentage}%` }}
                    ></div>
                  </div>
                  <button
                    onClick={() => handleDeleteClick(expense.id, expense.description)}
                    className="ml-2 px-2 py-1 bg-red-100 text-red-700 rounded-md text-xs hover:bg-red-200"
                  >
                    Eliminar
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default VariableExpensesTable;